# Spawoz Technologies Laravel Machine Test

#### Topic : Create a phone contact book with a web interface.

## Laravel

Laravel is a web application framework with expressive, elegant syntax. We’ve already laid the foundation — freeing you to create without sweating the small things.

## Installation

### Create Database

You must create your database on your server and on your .env file update the following lines:

```bash
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=homestead
DB_USERNAME=homestead
DB_PASSWORD=secret
```

### Composer

```bash
composer install
```


### Artisan Commands

The first thing we are going to do is set the key that Laravel will use when doing encryption.

```bash
php artisan key:generate
```

### Database Migration 

```bash
php artisan migrate

```

### URL:

http://127.0.0.1:8000/contacts

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.
